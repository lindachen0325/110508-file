var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/sign_up', function(req, res, next) {
  res.render('sign_up', { title: 'Express' });
});

router.get('/sign_in', function(req, res, next) {
  res.render('sign_in', { title: 'Express' });
});

router.get('/journals', function(req, res, next) {
  res.render('journals', { title: 'Express' });
});

router.get('/sign_out', function(req, res, next) {
  res.render('sign_out', { title: 'Express' });
});

router.get('/bookcase', function(req, res, next) {
  res.render('bookcase', { title: 'Express' });
});

router.get('/newbookself', function(req, res, next) {
  res.render('newbookself', { title: 'Express' });
});

router.get('/newnote', function(req, res, next) {
  res.render('newnote', { title: 'newnote' });
});



module.exports = router;


