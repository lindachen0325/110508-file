var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
//------------------------------------------------------------
// 增加引用模組
//------------------------------------------------------------
var session = require('express-session');

var bookshelf_update_name = require('./routes/bookshelf_update_name');
var bookshelf_update_form = require('./routes/bookshelf_update_form');
var bookshelf_update = require('./routes/bookshelf_update');

var journal_add_form = require('./routes/journal_add_form');
var journal_add = require('./routes/journal_add');
var bookshelf_remove_form = require('./routes/bookshelf_remove_form');
var bookshelf_remove = require('./routes/bookshelf_remove');
var bookshelf_add_form = require('./routes/bookshelf_add_form');
var bookshelf_add = require('./routes/bookshelf_add');
var journallist = require('./routes/bookshelf_journal');
var pagelist = require('./routes/journal_page');
var member_add_form = require('./routes/member_add_form');
var member_add = require('./routes/member_add');
var user_login_form = require('./routes/user_login_form');
var user_login = require('./routes/user_login');
var user_logout = require('./routes/user_logout');
var user_show = require('./routes/user_show');
var checkAuth = require('./routes/checkAuth');
//------------------------------------------------------------
var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
//----------------------------------------
// 可由外部直接取用資料夾
//----------------------------------------
app.use(express.static('public/photo'));
//-----------------------------------------
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({secret: 'cute', cookie: { maxAge: 60000 }}));
app.use(express.static(path.join(__dirname, 'img')));
app.use('/img', express.static('img'));
app.use('/', indexRouter);
app.use('/users', usersRouter);

//-----------------------------------------
//-----------------------------------------
//-----------------------------------------
// 設定模組使用方式
//-----------------------------------------
app.use('/bookshelf/update/name',checkAuth , bookshelf_update_name);
app.use('/bookshelf/update/form',checkAuth , bookshelf_update_form);
app.use('/bookshelf/update',checkAuth , bookshelf_update);

app.use('/journal/add/form',checkAuth , journal_add_form);
app.use('/journal/add',checkAuth , journal_add);
app.use('/bookshelf/remove/form',checkAuth , bookshelf_remove_form);
app.use('/bookshelf/remove',checkAuth , bookshelf_remove);
app.use('/bookshelf/add/form',checkAuth , bookshelf_add_form);
app.use('/bookshelf/add',checkAuth , bookshelf_add);
app.use('/bookcase',checkAuth , journallist);
app.use('/myJournals',checkAuth , pagelist);
app.use('/member/add/form', member_add_form);
app.use('/member/add', member_add);
app.use('/user/login/form', user_login_form);
app.use('/user/login', user_login);
app.use('/user/logout', user_logout);
app.use('/user/show',checkAuth , user_show);
//-----------------------------------------
// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
