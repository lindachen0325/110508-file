'use strict';

//引用操作資料庫的物件
const sql = require('./asyncDB');

//------------------------------------------
//執行資料庫動作的函式-傳回所有產品資料
//------------------------------------------
var journallist = async function(){
    var result=[];
	
    await sql('select journal.jouname,journal.photo,bookshelf.bsfname from bookshelf_journal left join journal on bookshelf_journal.jouno=journal.jouno left join bookshelf on bookshelf_journal.bsfno=bookshelf.bsfno;')
        .then((data) => {            
            result = data.rows;  
        }, (error) => {
            result = null;
        });
		
    return result;
}

//匯出
module.exports = {journallist};