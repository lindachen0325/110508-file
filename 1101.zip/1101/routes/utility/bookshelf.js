'use strict';

//引用操作資料庫的物件
var moment = require('moment');
const sql = require('./asyncDB');

//------------------------------------------
//執行資料庫動作的函式-新增會員書櫃
//------------------------------------------
var addbsf = async function(newData){
    var result;

    await sql('select * from bookshelf where memno=$1',[result[0].memno])
        .then((data) => {
            result = data.rows;
        }, (error) => {
            result = null;
        });

    await sql('INSERT INTO bookshelf (bsfname,createdate,privatest,memno) VALUES ($1, $2, $3,$4)', [newData.bsfname, moment().format("YYYY-MM-DD"),'0',result[0].memno])
        .then((data) => {
            result = 0;  
        }, (error) => {
            result = -1;
        });

        
		
    return result;
}

//匯出
module.exports = {addbsf};