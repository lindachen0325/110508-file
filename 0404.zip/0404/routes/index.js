var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/bookcase', function(req, res, next) {
  res.render('bookcase', { title: 'Express' });
});

router.get('/journals', function(req, res, next) {
  res.render('journals', { title: 'Express' });
});

module.exports = router;


